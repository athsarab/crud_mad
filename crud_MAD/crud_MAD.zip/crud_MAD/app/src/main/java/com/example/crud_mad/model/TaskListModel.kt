package com.example.crud_mad.model

class TaskListModel {
    var id : Int =0
    var name : String = ""
    var details : String = ""
}